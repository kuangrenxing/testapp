<?php 
include_once 'common/define.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>谁为你转身 - 中国好声音 - 应用小测试 - 拖拉网</title>
<link href="src/css/style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript"> 
window.onload=function(){ 
for(var ii=0; ii<document.links.length; ii++) document.links[ii].onfocus=function(){this.blur()} 
} 
</script>
</head>
 
<body id="ztBodyBg">
<div id="ztcontainer">
    <div id="ztcontent">
        <div class="BG1">
        	<div class="head">
            	<div class="head1 left">
                	<a href="http://www.tuolar.com" class="logo"><img title="拖拉网" src="src/images/img_start_03.jpg"/></a>
                    <img title="" class="s1" src="src/images/img_start_06.jpg"/>
                </div>
                <div class="head2 ">
                	<img src="src/images/img_08.jpg" title="中国好声音"/>
                </div>
            </div>
            <div class="content_2">
            	<div class="banner2">
                	<div class="d3">
                    	<div class="d4">
                        	<img src="src/images/user_03.jpg"/>
                            <p> ***中国好声音由凉茶领导者***冠名播出，***凉茶，正宗好凉茶，很可惜没有老师为你转身</p>
                        </div>
                        <div class="d5">
                        	<a href="attention.php?artist=0" target="_blank"><img src="src/images/focus_03.jpg"/></a>
                            <a href="song.php" target=""><img src="src/images/signAgain_03.jpg"/></a>
                        </div>
                    </div> 
                </div>
            </div>
        </div>            
  	</div>
  	<div class="ztfooter"><p>Copyright Tuolar.com All Rights Reserved</p></div>	
</div>

</body>
</html>