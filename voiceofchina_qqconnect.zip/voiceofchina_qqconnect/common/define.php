<?php
define("BASEURL", "http://testapp.dev/voiceofchina_qqconnect/");
define("TUOLARQZONE", "http://user.qzone.qq.com/622001561");

define('WB_APP_CONN_WEIFUSHI' , 324);