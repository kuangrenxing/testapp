<?php
define( "APP_DOMAIN" , "http://www.tuolar.com/");
define( "APP_SINA_URL" , "http://laohujiweibo.dev/");

define( "APP_qzone_URL" , "http://laohujiweibo.dev/");

define("BASEURL", "http://testapp.dev/youthroad_qqweibo/");
//填写自己的appid
define("CLIENT_ID", "801235368");
//填写自己的appkey
define("CLIENT_SECRET", "e6a268336ca7b781e65f069ad748feac");
define("DEBUG", false);//调试模式

define('WB_APP_CONN_WEIFUSHI' , 322);
?>