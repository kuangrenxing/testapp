<?php
//define('TUOLAR_DOMAIN' , 'http://www.tuolar.com');

define('CONNECT_TYPE_SINA' , 1);//新浪
define('SINA_APPKEY' , '2571764283');
define('SINA_APPSECRET' , 'd7aeb4eb18545aab08a0c0a69b155032');
define('SINA_CALLBACK' , "");

define('CONNECT_TYPE_QQT' , 2);//QQ微博
define('QQT_APPKEY' , 'b7720f12ccef4164a9013b2edd899e6f');
define('QQT_APPSECRET' , '670c717e9a331d367c93bf39567352db');
define('QQT_CALLBACK' , "");
define( "MB_RETURN_FORMAT" , 'json' );
define( "MB_API_HOST" , 'open.t.qq.com' );

define('CONNECT_TYPE_QZONE' , 3);//QQ空间
define('QZONE_APPID' , 'b7720f12ccef4164a9013b2edd899e6f');
define('QZONE_APPKEY' , '');
define('QZONE_CALLBACK' , "");

define('CONNECT_TYPE_DOUBAN' , 4);//豆瓣
define('DOUBAN_APPKEY' , '0ff262ca8540f14a2fd7285f8fc2d3de');
define('DOUBAN_APPSECRET' , '641d35b0bd3ac4b2');

define('CONNECT_TYPE_SINA_FOLLOW' , 5);//新浪微博关注
define('TUOLAR_WB_UID' , 1761623191);
define('SINA_FOLLOW_APPKEY' , '2571764283');
define('SINA_FOLLOW_APPSECRET' , 'ecd6679ccfeaf780ee66448c7cd49566');
define('SINA_FOLLOW_CALLBACK' , "");

define('CONNECT_TYPE_QQ' , 3);


?>